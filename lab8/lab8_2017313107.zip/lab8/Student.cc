#include "Student.hh"

Student::Student(){}
Student::Student(int y, int sem, int sub)
{
    year = y;
    semester = sem;
    subject = sub;
}
void Student::plus_credit(float sc, int cr)
{
    score.push_back(sc);
    credit.push_back(cr);
}
void Student::set_last_TF(char l)
{
    last_TF = l;
}
int Student::get_semester(){return semester;}
int Student::get_year(){return year;}
int Student::get_subject(){return subject;}
float Student::get_score(int i){return score[i];}
int Student::get_credit(int i){return credit[i];}
char Student::get_last_TF(){return last_TF;}

