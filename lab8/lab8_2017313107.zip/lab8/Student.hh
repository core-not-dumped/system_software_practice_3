#include <iostream>
#include <string>
#include <vector>

class Student{

private:
    int year;
    int semester;
    int subject;
    char last_TF;
    std::vector<float> score;
    std::vector<int> credit;

public:
    Student();
    Student(int y, int sem, int sub);
    void plus_credit(float sc, int cr);
    void set_last_TF(char l);
    int get_semester();
    int get_year();
    int get_subject();
    float get_score(int i);
    int get_credit(int i);
    char get_last_TF();
};

// year, semester, subject constructor
// plus_credit
// set_last_TF
// get_semester
// get_year
// get_subject
// get_score
// get_credit
// get_last_TF
