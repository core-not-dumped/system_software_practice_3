#include "Student.hh"

int main()
{
    // TODO: Fill Your Code 
    // Note: You must solve this problem using array of obejects.
    Student stu[10];
    for(int i=0;i<10;i++)
    {
        int year, semester, subject;
        std::cin >> year >> semester >> subject;

        stu[i] = Student(year, semester, subject);

        for(int j=0;j<subject;j++)
        {
            std::string s;
            float score;
            int credit;

            std::cin >> s;

            if(s[0] == 'A')         score = 4.0;
            else if(s[0] == 'B')    score = 3.0;
            else if(s[0] == 'C')    score = 2.0;
            else if(s[0] == 'D')    score = 1.0;
            else                    score = 0.0;

            if(s[1] == '+')         score += 0.5;

            credit = s[s.length() - 1] - '0';

            stu[i].plus_credit(score, credit);
        }

        char last_TF;
        std::cin >> last_TF;
        stu[i].set_last_TF(last_TF);
    }

    for(int i=0;i<10;i++)
    {
        int year = stu[i].get_year();
        int semester = stu[i].get_semester();
        int subject = stu[i].get_subject();
        char last_TF = stu[i].get_last_TF();
        if(semester >= 8)
        {
            std::cout << "PF" << std::endl;
            continue;
        }
        if(year >= 19 && semester >= 4)
        {
            std::cout << "PF" << std::endl;
            continue;
        }

        int ch = 0;
        float sum_score = 0;
        int sum_credit = 0;
        for(int j=0;j<subject;j++)
        {
            float score = stu[i].get_score(j);
            int credit = stu[i].get_credit(j);
            if(score == 0)  ch = 1;
            sum_score += score * credit;
            sum_credit += credit;
        }

        if(ch == 1)
        {
            if(last_TF == 'F')      std::cout << "PF" << std::endl;
            else                    std::cout << "F" << std::endl;
            continue;
        }

        if(sum_credit < 9 && semester == 7)
        {
            if(last_TF == 'F')      std::cout << "PF" << std::endl;
            else                    std::cout << "F" << std::endl;
            continue;
        }

        if(sum_credit < 12 && semester != 7)
        {
            if(last_TF == 'F')      std::cout << "PF" << std::endl;
            else                    std::cout << "F" << std::endl;
            continue;
        }

        float average = (float)sum_score / (float)sum_credit;
        if(average < 3.00)
        {
            if(last_TF == 'F')      std::cout << "PF" << std::endl;
            else                    std::cout << "F" << std::endl;
            continue;
        }

        std::cout << "T" << std::endl;
    }
}

// year, semester, subject constructor
// plus_credit
// set_last_TF
// get_semester
// get_year
// get_subject
// get_score
// get_credit
// get_last_TF
