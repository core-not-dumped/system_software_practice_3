# How To Run

    $ make
    $ ./bin/main.out [cache_capacity] ./data/in.txt ./data/out.txt ./data/cin.txt

# Example Result

    $ ./bin/main.out 4 ./data/in.txt ./data/out.txt ./data/cin.txt

Current Time : 0

Read 1022050296 Finish At Time 5

Read 823534624 Finish At Time 10

Read 2883690328 Finish At Time 15

Read 2125508080 Finish At Time 20

Read 1022050296 Finish At Time 21

Read 1995960632 Finish At Time 26

Read 1022050296 Finish At Time 27

Read 823534624 Finish At Time 32

Read 2883690328 Finish At Time 37

Read 2125508080 Finish At Time 42
