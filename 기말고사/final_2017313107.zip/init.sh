mkdir Problem2/bin
mkdir Problem2/obj
mkdir Problem1/bin
mkdir Problem1/obj
mkdir Problem3/obj
mkdir Problem3/bin
