# System Software Practice Final Exam

## Good Luck~!

## Initialize

 $ sh init.sh

## Submission
 $ sh submission.sh [student_id]

