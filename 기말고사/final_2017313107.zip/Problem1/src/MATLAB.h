template<class T>
class Matrix{
    public:
        //implement your class member function definition as written in paper.
        Matrix(int r, int c);
        Matrix(const Matrix& M);
        ~Matrix();
        void set_value(int r, int c, T val);
        T get_value(int r, int c);
        void print_matrix();
        Matrix operator +(Matrix rhs);
        Matrix operator +(T rhs);
        Matrix operator -(Matrix rhs);
        Matrix operator -(T rhs);
        Matrix operator *(Matrix rhs);
        Matrix operator *(T rhs);
        void operator =(const Matrix& rhs);
    private:
        T* value;
        int rownum;
        int colnum;
};

//implement your class member functions as written in paper.

template<class T>
void Matrix<T>::print_matrix(){
    for(int i=0;i<rownum;i++){
        for(int j=0;j<colnum;j++){
            std::cout << value[i * colnum + j] << " ";
        }
        std::cout << std::endl;
    }
}

template<class T>
Matrix<T>::Matrix(int r, int c): rownum(r), colnum(c){
    value = new T[r * c];
    for(int i=0;i<r*c;i++)  value[i] = 0;
}

template<class T>
Matrix<T>::Matrix(const Matrix<T>& M)
{
    colnum = M.colnum;
    rownum = M.rownum;
    value = new T[colnum * rownum];
    for(int i=0;i<rownum*colnum;i++)  value[i] = M.value[i];
}

template<class T>
Matrix<T>::~Matrix()
{
    delete [] value;
}

template<class T>
void Matrix<T>::set_value(int r, int c, T val)
{
    value[r * colnum + c] = val;
}

template<class T>
T Matrix<T>::get_value(int r, int c)
{
    return value[r * colnum + c];
}

template<class T>
Matrix<T> Matrix<T>::operator +(Matrix rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r*c; i++)
        M.value[i] = (*this).value[i] + rhs.value[i];
    return M;
}

template<class T>
Matrix<T> Matrix<T>::operator +(T rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r*c; i++)
        M.value[i] = (*this).value[i] + rhs;
    return M;
}

template<class T>
Matrix<T> Matrix<T>::operator *(Matrix rhs)
{
    int c = rhs.colnum;
    int l = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r; i++)
    {
        for(int j=0;j<c;j++)
        {
            for(int k=0;k<l;k++)
            M.value[i*c+j] += (*this).value[i*l+k] * rhs.value[k*c+j];
        }
    }
    return M;
}

template<class T>
Matrix<T> Matrix<T>::operator *(T rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r*c; i++)
        M.value[i] = (*this).value[i] * rhs;
    return M;
}

template<class T>
Matrix<T> Matrix<T>::operator -(Matrix rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r*c; i++)
        M.value[i] = (*this).value[i] - rhs.value[i];
    return M;
}

template<class T>
Matrix<T> Matrix<T>::operator -(T rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    Matrix M(r, c);
    for(int i=0; i<r*c; i++)
        M.value[i] = (*this).value[i] - rhs;
    return M;
}

template<class T>
void Matrix<T>::operator =(const Matrix& rhs)
{
    int c = (*this).colnum;
    int r = (*this).rownum;
    for(int i=0; i<r*c; i++)
        (*this).value[i] = rhs.value[i];
}





















