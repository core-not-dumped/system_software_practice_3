#include "inheritance1.hh"
#include "inheritance2.hh"

int main(){

  // Problem1
  test1();
  
  // Problem2
  James* var1 = new Donard(); 
  Richard* var2 = new Edward(); 
  Richard* var3 = new Donard(); 
  Edward* var4 = new Edward(); 
  Donard* var5 = new Edward(); 
  James* var6 = new Richard(); 
  

}
