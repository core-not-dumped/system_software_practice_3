zip -r final_$1.zip ./*
