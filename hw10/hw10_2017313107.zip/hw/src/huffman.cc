/* *************************************************************************************************************
 * Copyright (c) 2021 Donghun-Jeong, Seokin-Hong, Sungkyunkwan Universit All Right Reserved
 *
 * - File Name : huffman.cc
 * - File Type : c++ header code
 * - File Version(Last Update Date) : 1.0
 * - Date : Oct. 26, 2021.
 * - Description : This code is provided huffman code for SSE2034-41(SKKU, 2021) class HW 10.
 *                 Do not distribute this code without permission.
 * *************************************************************************************************************/

#include "huffman.h"
#include <cassert>
#include <algorithm>

namespace Huffman{

    node::node(std::vector<uint8_t> symbols_, size_t count_)
    {
        symbols = symbols_;
        count = count_;
        left = NULL;
        right = NULL;
    }

    node::node(std::vector<uint8_t> symbols_, size_t count_, node *left_, node *right_)
    {
        symbols = symbols_;
        count = count_;
        left = left_;
        right = right_;
    }

    node::~node()
    {
        if (left != NULL) delete left;
        if (right != NULL) delete right;
    }

    std::vector<uint8_t> node::get_symbols() const {return symbols;}

    size_t node::get_count() const {return count;}

    node *node::get_left() const {return left;}
    node *node::get_right() const {return right;}

    node *merge_node(node *lhs, node *rhs){
        std::vector<uint8_t> s;
        for(size_t i=0;i<(lhs->get_symbols()).size();i++)
            s.push_back((lhs->get_symbols()).at(i));
        for(size_t i=0;i<(rhs->get_symbols()).size();i++)
            s.push_back((rhs->get_symbols()).at(i));
        node *merge_node = new node(s,lhs->get_count() + rhs->get_count(),lhs,rhs);
        return merge_node;
    }

    bool is_smaller(node *lhs, node *rhs) {
        if(lhs->get_count() > rhs->get_count()) return 1;
        if(lhs->get_count() < rhs->get_count()) return 0;

        if((lhs->get_symbols()).size() > (rhs->get_symbols()).size())   return 1;
        if((lhs->get_symbols()).size() < (rhs->get_symbols()).size())   return 0;

        uint8_t small_l = 0xff;
        uint8_t small_r = 0xff;
        for(size_t i=0;i<(lhs->get_symbols()).size();i++)     small_l = small_l < (lhs->get_symbols())[i] ? small_l : (lhs->get_symbols())[i];
        for(size_t i=0;i<(rhs->get_symbols()).size();i++)     small_r = small_r < (rhs->get_symbols())[i] ? small_r : (rhs->get_symbols())[i];
        if(small_l > small_r)   return 1;
        return 0;
    }

    PriorityNodeQueue::PriorityNodeQueue()
    {
        nodes.clear();
    }

    void PriorityNodeQueue::push(node *node_ptr) {
        nodes.push_back(node_ptr);
        sort();
    }

    node *PriorityNodeQueue::front() {
        return nodes.at(0);
    }

    node *PriorityNodeQueue::pop() {
        node *result = nodes[0];
        nodes.erase(nodes.begin());
        return result;
    }

    PriorityNodeQueue::~PriorityNodeQueue() {
        //TODO : left and right ?
        size_t s = nodes.size();
        for(size_t i=0;i<s;i++)
            delete [] nodes[i];
    }

    size_t PriorityNodeQueue::size() {return nodes.size();}

    bool PriorityNodeQueue::empty(){return (nodes.size()==0);}

    void PriorityNodeQueue::sort() {
        for(size_t i=0;i<nodes.size();i++)
        {
            for(size_t j=0;j<nodes.size()-i-1;j++)
            {
                if(is_smaller(nodes[j],nodes[j+1])) //j+1 smaller -> 1
                {
                    node *tmp = nodes[j];
                    nodes[j] = nodes[j+1];
                    nodes[j+1] = tmp;
                }
            }
        }
    }

    tree::tree() {
        root = NULL;
        priority_node_queue = NULL;
        //TODO
    }

    tree::tree(std::vector<uint8_t> symbols, std::vector<size_t> count) {
        //TODO symbol table -> sort
        
        //sort symbol table
        symbol_table = symbols;
        for(size_t i=0;i<symbol_table.size();i++)
        {
            for(size_t j=0;j<symbol_table.size()-i-1;j++)
            {
                if(symbol_table[j] > symbol_table[j+1])
                {
                    int tmp = symbol_table[j+1];
                    symbol_table[j+1] = symbol_table[j];
                    symbol_table[j] = tmp;
                }
            }
        }

        PriorityNodeQueue *priority_node_queue = new PriorityNodeQueue;
        for(size_t i=0;i<symbols.size();i++)
        {
            std::vector<uint8_t> s = {symbols[i]};
            size_t c = count[i];
            node *new_node = new node(s, c);
            priority_node_queue->push(new_node);
        }
        
        while(priority_node_queue->size() > 1)
        {
            node *node1 = priority_node_queue->pop();
            node *node2 = priority_node_queue->pop();
            node *new_node = merge_node(node2, node1);
            priority_node_queue->push(new_node);
        }
        root = priority_node_queue->pop();

        for(size_t i=0;i<symbol_table.size();i++)
        {
            std::string str = "";
            node *current_node = root;
            while(current_node->get_left() != NULL && current_node->get_right() != NULL)
            {
                int ch = 0;
                std::vector<uint8_t> l_symbol = (current_node->get_left()->get_symbols());
                for(size_t j=0;j<l_symbol.size();j++)
                {
                    if(symbol_table[i] == l_symbol[j])  ch = 1;
                }
                if(ch == 0)
                {
                    current_node = current_node->get_right();
                    str += '1';
                }
                else
                {
                    current_node = current_node->get_left();
                    str += '0';
                }
            }
            encoding_table.push_back(str);
        }
    }

    tree::~tree() {
        //TODO
        delete [] priority_node_queue;
    }

    std::string tree::encode_symbols(std::vector<uint8_t> symbols) const {
        //TODO
        std::string ret = "";
        for(size_t i=0;i<symbols.size();i++)
        {
            size_t j;
            for(j=0;j<symbol_table.size();j++)
            {
                if(symbols[i] == symbol_table[j])   break;
            }
            ret += encoding_table[j];
        }
        return ret;
    }

    std::vector<uint8_t> tree::decode_symbols(std::string encode_symbols) {
        //TODO
        std::vector<uint8_t> ret;
        node *current_node = root;
        for(size_t i=0;i<encode_symbols.size();i++)
        {
            if(encode_symbols[i] == '0')
            {
                if(current_node->get_left() == NULL)
                {
                    ret.push_back((current_node->get_symbols())[0]);
                    current_node = root->get_left();
                }
                else
                    current_node = current_node->get_left();
            }
            else
            {
                if(current_node->get_right() == NULL)
                {
                    ret.push_back((current_node->get_symbols())[0]);
                    current_node = root->get_right();
                }
                else
                    current_node = current_node->get_right();
            }
        }
        ret.push_back((current_node->get_symbols())[0]);
        return ret;
    }

    tree *get_tree(std::vector <uint8_t> original_data) {
        //TODO
        std::vector<size_t> c(256);
        std::vector<size_t> c_real;
        for(size_t i=0;i<original_data.size();i++)
            c[original_data[i]]++;
        
        std::vector<uint8_t> s;
        for(size_t i=0;i<256;i++)
        {
            if(c[i] != 0)
            {
                s.push_back((uint8_t)i);
                c_real.push_back(c[i]);
            }
        }
        
        tree *ret = new tree(s,c_real);
        return ret;
    }
}
