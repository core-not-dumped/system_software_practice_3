#include "string.h"
#include <iostream>

String::String() {char_array.clear();}

String::String(char str[])
{
    size_t i=0;

    while (str[i] != '\0') {
        char_array.push_back(str[i]);
        i++;
    }
}

String::String(std::vector<char> str) {char_array = str;}

size_t String::len() {
    size_t size = char_array.size();

    return size;
}

char String::at(size_t idx) {return char_array.at(idx);}

void String::set(size_t idx, char c) {char_array.at(idx) = c;}

size_t String::find(char c) {

    size_t i;

    for (i=0; i<char_array.size(); i++){
        if (char_array.at(i) == c) return c;
    }

    return i;
}

size_t String::end() {return (size_t)char_array.size();}

void String::print(){
    for (size_t i=0; i<char_array.size(); i++) {
        std::cout << char_array.at(i);
    }
}

void print(String str) {
    //TODO : Same operation as String::print().
    str.print();
    return;
}

std::vector<String> split(String str, char divide){
    //TODO : divide string into char divide
    //Ex) str = "This is example.", divide = ' '
    //Ex) return vector<String> = {"This", "is", "example."}
    std::vector<String> trim;
    
    String s;
    std::vector<char> tmp;
    for(size_t i=0;i<str.len();i++)
    {
        if(str.at(i) == divide)
        {
            s = tmp;
            trim.push_back(s);
            tmp.clear();
        }
        else
            tmp.push_back(str.at(i));
    }
    if(tmp.size() != 0)
    {
        s = tmp;
        trim.push_back(s);
    }

    return trim;
}

String String::operator +(String rhs) {
    //TODO : return string lhs + string rhs
    //Ex) "This is " + "example." = "This is example."
    String s;
    std::vector<char> str;
    for(size_t i=0;i<(*this).len();i++)     str.push_back((*this).at(i));
    for(size_t i=0;i<rhs.len();i++)         str.push_back(rhs.at(i));
    s = str;

    return s;
}

String String::operator +(char rhs[]) {
    //TODO : String lhs + char rhs[]
    //Hint : Convert rhs to String
    String s;
    std::vector<char> str;
    for(size_t i=0;i<(*this).len();i++)     str.push_back((*this).at(i));
    size_t i = 0;
    while(rhs[i] != '\0')                   str.push_back(rhs[i++]);
    s = str;

    return s;
}

void String::operator += (String rhs) {
    //TODO : *this = *this + rhs;
    *this = *this + rhs;
}

void String::operator += (char rhs[]) {
    //TODO : *this = *this + rhs;
    *this = *this + rhs;
}

void String::operator =(char rhs[]) {
    //TODO : assign *this as rhs;
    size_t i=0;

    (*this).char_array.clear();
    while (rhs[i] != '\0')
        (*this).char_array.push_back(rhs[i++]);
}

void String::operator =(std::vector<char> rhs) {
    //TODO : assign *this as rhs
    (*this).char_array.clear();
    for(size_t i=0;i < rhs.size();i++)      (*this).char_array.push_back(rhs[i]);
}

String String::operator *(unsigned rhs) {
    //TODO : String lhs * unsigned rhs
    //Ex) "AB" * 3 = "ABABAB"
    String s;
    for(size_t i=0;i<rhs;i++)
        s += *this;

    return s;
}

void String::operator *= (unsigned rhs) {
    //TODO : *this = *this * rhs;
    *this = *this * rhs;
}

char String::operator [](size_t rhs) const{
    //TODO : return rhs index character in *this
    return (*this).char_array[rhs];
}

String String::operator <<(size_t rhs) {
    //TODO : Rotational Shift Left as RHS
    //Ex) "ABCD" << 1 = "BCDA" 
    rhs %= (*this).len();

    String s;
    std::vector<char> str;
    for(size_t i=rhs;i<(*this).len();i++)   str.push_back((*this).at(i));
    for(size_t i=0;i<rhs;i++)               str.push_back((*this).at(i));
    s = str;

    return s;
}

String String::operator >>(size_t rhs) {
    //TODO : Rotational Shifht Right as rhs
    //Ex) "ABCD" >> 1 = "DABC"
    rhs %= ((*this).len());

    String s;
    std::vector<char> str;
    for(size_t i=(*this).len() - rhs;i<(*this).len();i++)   str.push_back((*this).at(i));
    for(size_t i=0;i<(*this).len() - rhs;i++)               str.push_back((*this).at(i));
    s = str;

    return s;
}

bool String::operator ==(String rhs) {
    //TODO : if all characters are same -> return true
    if ((*this).len() != (*this).len())
        return false;

    for(size_t i=0;i<(*this).len();i++)
    {
        if((*this).at(i) != rhs.at(i))   return false;
    }
    return true;
}

bool String::operator !=(String rhs) {
    //TODO : if !(lhs == rhs) -> return true
    if ((*this).len() != (*this).len())
        return true;

    for(size_t i=0;i<(*this).len();i++)
    {
        if((*this).at(i) != rhs.at(i))   return true;
    }
    return false;
}
