
//You can write code in any part except between /***********/ region.
//You cannot include any other libraries except vector and string.
/********************************************************************************************/
#ifndef MATRIX_H
#define MATRIX_H

#include <vector>
#include <string>

class MATRIX {

    public:
        friend bool is_greater_than(MATRIX A, MATRIX B);
        friend bool is_smaller_than(MATRIX A, MATRIX B);
        friend bool operator > (MATRIX A, MATRIX B);
        friend bool operator < (MATRIX A, MATRIX B);
        friend bool operator >= (MATRIX A, MATRIX B);
        friend bool operator <= (MATRIX A, MATRIX B);

        MATRIX(void);
        MATRIX(size_t row_size, size_t col_size);
        MATRIX(std::vector<int> data, size_t row_size, size_t col_size);
        std::string to_string() const;
        size_t get_size() const;
        std::vector <size_t> get_dimension() const;
        
        int at(size_t row, size_t col) const;
        void at(size_t row, size_t col, int data);
        MATRIX at(std::string range) const;
        void at(std::string range, std::vector<int> data);
        MATRIX operator [](std::string range);
        MATRIX operator +(MATRIX rhs);
        MATRIX operator -(MATRIX rhs);
        MATRIX operator *(MATRIX rhs);
        void operator +=(MATRIX rhs);
        void operator -=(MATRIX rhs);
        void operator *=(MATRIX rhs);
        MATRIX operator +(int rhs);
        MATRIX operator *(int rhs);
        friend MATRIX operator -(MATRIX A, int B);
        friend MATRIX operator -(int A, MATRIX B);
        void operator +=(int rhs);
        void operator -=(int rhs);
        void operator *=(int rhs);
        bool operator ==(MATRIX rhs);
        bool operator !=(MATRIX rhs);

    private:
        size_t n_row, n_col;
        std::vector <int> data_array;
};

#endif
/********************************************************************************************/
