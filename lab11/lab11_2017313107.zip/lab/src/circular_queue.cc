#include "circular_queue.hh"

bool CircularQueue::isEmpty() {
    // TODO: Fill Your Code Here
    if(front == -1)     return true;
    else                return false;
}

bool CircularQueue::isFull() {
    // TODO: Fill Your Code Here
    if(front == 0 && rear == getCapacity() - 1)     return true;
    if(front == rear + 1)                           return true;
    return false;
}

void CircularQueue::enqueue(int n){
    // TODO: Fill Your Code Here
    if(front == -1) front = 0;
    rear = (rear + 1) % getCapacity();
    insert(rear, n);
}

int CircularQueue::dequeue(){
    // TODO: Fill Your Code Here
    int element;
    element = get(front);
    if(front == rear)
    {
        front = -1;
        rear = -1;
    }
    else
        front = (front + 1) % getCapacity();
    return element;
}
